/* class Node {
	int data;
	Node left;
	Node right;

	Node(int data) {
		this.data = data;
		left = null;
		right = null;
	}
}*/

public class BinaryTree {
	Node covertMirror(Node node) {
	    return null;
	}

	int getWidthTree(Node node) {
		return 0;
	}

}