package week3.LTT3.example2;

interface stack<T> {
    void push(T data);
    T pop();
    int size();
    boolean isEmpty();
    void show();
}