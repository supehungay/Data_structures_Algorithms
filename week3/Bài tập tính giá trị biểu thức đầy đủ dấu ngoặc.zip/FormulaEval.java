
public class FormulaEval {

	public double eval(String formula)
	{
		
		return 0;
	}


}
