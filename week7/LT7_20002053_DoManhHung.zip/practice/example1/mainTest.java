package week7.practice.example1;

import java.util.Random;

public class mainTest {
    
	public static void main(String[] args) {
		int[] array = new int[10];
		Random random = new Random();
		System.out.println(random.nextInt(10));
	}
}
